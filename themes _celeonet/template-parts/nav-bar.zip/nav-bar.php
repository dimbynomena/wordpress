<?php
  wp_nav_menu( array(
    'menu'              => 'main',
    'theme_location'    => 'main',
    'depth'             => 2,
    'menu_class'        => 'nav navbar-nav',
    )
  );
?>